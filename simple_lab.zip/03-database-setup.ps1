# ============================================================================
# 03-database-setup.ps1
# Run on: onprem-db01 (SQL Server Developer edition image)
# Purpose: Create the ContosoRetail database with a realistic normalized
#          schema (Products, Customers, Orders, OrderItems) + a stored
#          procedure, so the app tier has real relational work to do.
# ============================================================================

$sqlInstance = "localhost"
$appLoginPassword = "AppUser!$(Get-Random -Minimum 1000 -Maximum 9999)"

sqlcmd -S $sqlInstance -Q "
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'ContosoRetail')
BEGIN
    CREATE DATABASE ContosoRetail;
END
"

sqlcmd -S $sqlInstance -d ContosoRetail -Q "
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Products')
BEGIN
    CREATE TABLE Products (
        ProductId   INT IDENTITY(1,1) PRIMARY KEY,
        Sku         NVARCHAR(20)   NOT NULL UNIQUE,
        Name        NVARCHAR(100)  NOT NULL,
        Category    NVARCHAR(50)   NOT NULL,
        Price       DECIMAL(10,2)  NOT NULL,
        StockQty    INT            NOT NULL,
        LastUpdated DATETIME2      DEFAULT SYSUTCDATETIME()
    );
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Customers')
BEGIN
    CREATE TABLE Customers (
        CustomerId  INT IDENTITY(1,1) PRIMARY KEY,
        FullName    NVARCHAR(100) NOT NULL,
        Email       NVARCHAR(150) NULL,
        CreatedAt   DATETIME2 DEFAULT SYSUTCDATETIME()
    );
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Orders')
BEGIN
    CREATE TABLE Orders (
        OrderId     INT IDENTITY(1,1) PRIMARY KEY,
        CustomerId  INT NOT NULL FOREIGN KEY REFERENCES Customers(CustomerId),
        OrderDate   DATETIME2 DEFAULT SYSUTCDATETIME(),
        Status      NVARCHAR(20) DEFAULT 'Pending',
        TotalAmount DECIMAL(10,2) DEFAULT 0
    );
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderItems')
BEGIN
    CREATE TABLE OrderItems (
        OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
        OrderId     INT NOT NULL FOREIGN KEY REFERENCES Orders(OrderId),
        ProductId   INT NOT NULL FOREIGN KEY REFERENCES Products(ProductId),
        Quantity    INT NOT NULL,
        UnitPrice   DECIMAL(10,2) NOT NULL
    );
END
"

sqlcmd -S $sqlInstance -d ContosoRetail -Q "
IF NOT EXISTS (SELECT 1 FROM Products)
BEGIN
    INSERT INTO Products (Sku, Name, Category, Price, StockQty) VALUES
    ('SKU-1001', 'Wireless Mouse',        'Electronics', 19.99, 240),
    ('SKU-1002', 'Mechanical Keyboard',   'Electronics', 79.99, 120),
    ('SKU-1003', '27in Monitor',          'Electronics', 249.00, 60),
    ('SKU-1004', 'Standing Desk',         'Furniture',   399.00, 15),
    ('SKU-1005', 'Office Chair',          'Furniture',   189.50, 32),
    ('SKU-1006', 'Notebook 3-Pack',       'Office',      6.99,  500),
    ('SKU-1007', 'USB-C Hub',             'Electronics', 34.99, 175),
    ('SKU-1008', 'Desk Lamp',             'Furniture',   24.99, 90),
    ('SKU-1009', 'Whiteboard 4x3',        'Office',      59.00, 22),
    ('SKU-1010', 'Webcam 1080p',          'Electronics', 45.00, 88);
END

IF NOT EXISTS (SELECT 1 FROM Customers)
BEGIN
    INSERT INTO Customers (FullName, Email) VALUES
    ('Alex Rivera', 'alex.rivera@example.com'),
    ('Priya Nair',  'priya.nair@example.com'),
    ('Jordan Blake','jordan.blake@example.com');
END
"

# --- Stored procedure the app tier calls to place an order transactionally ---
sqlcmd -S $sqlInstance -d ContosoRetail -Q "
IF OBJECT_ID('dbo.usp_PlaceOrder', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_PlaceOrder;
"
sqlcmd -S $sqlInstance -d ContosoRetail -Q "
CREATE PROCEDURE dbo.usp_PlaceOrder
    @CustomerName NVARCHAR(100),
    @Sku          NVARCHAR(20),
    @Quantity     INT,
    @NewOrderId   INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;

    DECLARE @CustomerId INT, @ProductId INT, @Price DECIMAL(10,2);

    SELECT @CustomerId = CustomerId FROM Customers WHERE FullName = @CustomerName;
    IF @CustomerId IS NULL
    BEGIN
        INSERT INTO Customers (FullName) VALUES (@CustomerName);
        SET @CustomerId = SCOPE_IDENTITY();
    END

    SELECT @ProductId = ProductId, @Price = Price FROM Products WHERE Sku = @Sku;
    IF @ProductId IS NULL
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR('Unknown SKU', 16, 1);
        RETURN;
    END

    INSERT INTO Orders (CustomerId, Status, TotalAmount)
    VALUES (@CustomerId, 'Pending', @Price * @Quantity);
    SET @NewOrderId = SCOPE_IDENTITY();

    INSERT INTO OrderItems (OrderId, ProductId, Quantity, UnitPrice)
    VALUES (@NewOrderId, @ProductId, @Quantity, @Price);

    UPDATE Products SET StockQty = StockQty - @Quantity, LastUpdated = SYSUTCDATETIME()
    WHERE ProductId = @ProductId;

    COMMIT TRANSACTION;
END
"

# --- App login (SQL auth) so the API tier doesn't need Windows auth/domain ----
sqlcmd -S $sqlInstance -Q "
IF NOT EXISTS (SELECT name FROM sys.sql_logins WHERE name = 'contosoapp')
BEGIN
    CREATE LOGIN contosoapp WITH PASSWORD = '$appLoginPassword', CHECK_POLICY = OFF;
END
"
sqlcmd -S $sqlInstance -d ContosoRetail -Q "
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'contosoapp')
BEGIN
    CREATE USER contosoapp FOR LOGIN contosoapp;
    ALTER ROLE db_datareader ADD MEMBER contosoapp;
    ALTER ROLE db_datawriter ADD MEMBER contosoapp;
    GRANT EXECUTE ON dbo.usp_PlaceOrder TO contosoapp;
END
"

# --- Enable mixed-mode auth (SQL + Windows) via registry -----------------------
$instanceKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQLServer"
if (Test-Path $instanceKey) {
    Set-ItemProperty -Path $instanceKey -Name "LoginMode" -Value 2
}

# --- Enable TCP/IP protocol and open the Windows Firewall for 1433 -----------
Import-Module SqlServer -ErrorAction SilentlyContinue
try {
    $wmi = New-Object Microsoft.SqlServer.Management.Smo.WmiManagement "."
    $tcp = $wmi.ServerInstances["MSSQLSERVER"].ServerProtocols["Tcp"]
    $tcp.IsEnabled = $true
    $tcp.Alter()
} catch {
    Write-Output "Configure TCP/IP manually via SQL Server Configuration Manager if this step failed."
}

New-NetFirewallRule -DisplayName "SQL Server 1433" -Direction Inbound -Protocol TCP -LocalPort 1433 -Action Allow -ErrorAction SilentlyContinue

Restart-Service -Name "MSSQLSERVER" -Force

Write-Output "============================================================"
Write-Output "ContosoRetail database ready: Products, Customers, Orders, OrderItems"
Write-Output "Stored procedure usp_PlaceOrder created."
Write-Output "App SQL login: contosoapp"
Write-Output "App SQL password: $appLoginPassword"
Write-Output "IMPORTANT: copy this password now -- it is not stored anywhere else."
Write-Output "Pass it to 05-appapi-setup.ps1 as -DbPassword."
Write-Output "============================================================"
