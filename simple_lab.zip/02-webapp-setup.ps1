# ============================================================================
# 02-webapp-setup.ps1
# Run on: onprem-web01
# Purpose: Front-door web tier. Renders a dashboard by calling the app/API
#          tier over HTTP -- it never talks to the DB directly, so this VM
#          only depends on the App tier, and the App tier depends on the DB
#          and file server. That chain is what makes dependency-analysis
#          demos (Azure Migrate / AWS MGN wave planning) meaningful.
#
# Usage: .\02-webapp-setup.ps1 -AppServer "10.50.4.10" -ApiPort 8081
# ============================================================================
param(
    [Parameter(Mandatory = $true)][string]$AppServer,
    [int]$ApiPort = 8081
)

Install-WindowsFeature -Name Web-Server, Web-Asp-Net45, Web-Net-Ext45 -IncludeManagementTools

$siteRoot = "C:\inetpub\wwwroot\contosoretail"
New-Item -ItemType Directory -Path $siteRoot -Force | Out-Null

$webConfig = @"
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <appSettings>
    <add key="ApiBaseUrl" value="http://${AppServer}:${ApiPort}/" />
  </appSettings>
  <system.web>
    <compilation debug="false" targetFramework="4.8" />
    <httpRuntime targetFramework="4.8" />
  </system.web>
</configuration>
"@
Set-Content -Path "$siteRoot\web.config" -Value $webConfig -Encoding UTF8

$defaultAspx = @'
<%@ Page Language="C#" %>
<%@ Import Namespace="System.Net" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="System.Configuration" %>
<%@ Import Namespace="System.Text.RegularExpressions" %>
<%@ Import Namespace="System.Collections.Generic" %>
<!DOCTYPE html>
<html>
<head>
    <title>Contoso Retail</title>
    <style>
        body { font-family: Segoe UI, Arial, sans-serif; margin: 40px; background: #f4f6f8; color: #222; }
        h1 { margin-bottom: 4px; }
        .badge { display:inline-block; padding:4px 10px; border-radius:12px; font-size:12px; color:#fff; background:#0078d4; }
        .meta { color: #666; font-size: 13px; margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.1); margin-bottom: 30px; }
        th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #e1e1e1; }
        th { background: #0078d4; color: #fff; }
        tr:hover { background: #f0f8ff; }
        form.order { background:#fff; padding:16px; box-shadow: 0 1px 3px rgba(0,0,0,.1); margin-bottom:30px; max-width:420px; }
        form.order input, form.order select { display:block; width:94%; margin-bottom:10px; padding:6px; }
        form.order button { padding:8px 16px; background:#0078d4; color:#fff; border:none; cursor:pointer; }
        .error { color: #c00; }
        .tabs a { margin-right: 16px; text-decoration:none; color:#0078d4; font-weight:600; }
    </style>
</head>
<body>
    <h1>Contoso Retail <span class="badge" id="hostBadge" runat="server"></span></h1>
    <p class="meta" id="metaLine" runat="server"></p>
    <p class="tabs"><a href="?tab=products">Products</a> | <a href="?tab=order">Place Order</a> | <a href="?tab=orders">Recent Orders</a></p>

    <asp:Panel ID="ProductsPanel" runat="server">
        <h2>Products</h2>
        <table>
            <tr><th>SKU</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th></tr>
            <asp:Literal ID="ProductRows" runat="server" />
        </table>
    </asp:Panel>

    <asp:Panel ID="OrderPanel" runat="server" Visible="false">
        <h2>Place an Order</h2>
        <form class="order" method="post" action='<%= ApiBaseUrl %>orders.ashx'>
            <label>Customer name</label>
            <input type="text" name="customerName" required="required" />
            <label>SKU</label>
            <input type="text" name="sku" placeholder="e.g. SKU-1001" required="required" />
            <label>Quantity</label>
            <input type="number" name="qty" value="1" min="1" required="required" />
            <button type="submit">Submit Order</button>
        </form>
        <p class="meta">This form posts directly to the App tier's API at <%= ApiBaseUrl %>orders.ashx -- the web tier never touches the database.</p>
    </asp:Panel>

    <asp:Panel ID="OrdersPanel" runat="server" Visible="false">
        <h2>Recent Orders</h2>
        <table>
            <tr><th>Order #</th><th>Customer</th><th>Status</th><th>Total</th><th>Date</th></tr>
            <asp:Literal ID="OrderRows" runat="server" />
        </table>
    </asp:Panel>

    <script runat="server">
        public string ApiBaseUrl;

        protected void Page_Load(object sender, EventArgs e)
        {
            hostBadge.InnerText = Environment.MachineName;
            ApiBaseUrl = ConfigurationManager.AppSettings["ApiBaseUrl"];

            string tab = Request.QueryString["tab"];
            ProductsPanel.Visible = string.IsNullOrEmpty(tab) || tab == "products";
            OrderPanel.Visible = tab == "order";
            OrdersPanel.Visible = tab == "orders";

            if (ProductsPanel.Visible) LoadProducts();
            if (OrdersPanel.Visible) LoadOrders();
        }

        private string HttpGet(string path)
        {
            using (var client = new WebClient())
            {
                client.Headers.Add("Accept", "application/json");
                return client.DownloadString(ApiBaseUrl + path);
            }
        }

        // Minimal parser for the flat JSON arrays this specific API returns.
        // Not a general-purpose JSON parser -- matches the fixed shape emitted
        // by products.ashx / orders.ashx in 05-appapi-setup.ps1.
        private List<Dictionary<string,string>> ParseFlatJsonArray(string json)
        {
            var results = new List<Dictionary<string,string>>();
            foreach (Match obj in Regex.Matches(json, @"\{([^}]*)\}"))
            {
                var dict = new Dictionary<string,string>();
                foreach (Match kv in Regex.Matches(obj.Groups[1].Value, "\"(\\w+)\":(\"([^\"]*)\"|[^,}]+)"))
                {
                    string key = kv.Groups[1].Value;
                    string val = kv.Groups[3].Success ? kv.Groups[3].Value : kv.Groups[2].Value;
                    dict[key] = val;
                }
                results.Add(dict);
            }
            return results;
        }

        private void LoadProducts()
        {
            try
            {
                string json = HttpGet("products.ashx");
                var rows = ParseFlatJsonArray(json);
                var sb = new System.Text.StringBuilder();
                foreach (var p in rows)
                {
                    sb.Append("<tr><td>").Append(p["sku"]).Append("</td><td>").Append(p["name"])
                      .Append("</td><td>").Append(p["category"]).Append("</td><td>$").Append(p["price"])
                      .Append("</td><td>").Append(p["stock"]).Append("</td></tr>");
                }
                ProductRows.Text = sb.ToString();
                metaLine.InnerText = "Products loaded from App tier at " + ApiBaseUrl + "  |  Rows: " + rows.Count;
            }
            catch (Exception ex)
            {
                metaLine.InnerText = "Could not reach App tier: " + ex.Message;
                metaLine.Attributes["class"] = "error";
            }
        }

        private void LoadOrders()
        {
            try
            {
                string json = HttpGet("orders.ashx");
                var rows = ParseFlatJsonArray(json);
                var sb = new System.Text.StringBuilder();
                foreach (var o in rows)
                {
                    sb.Append("<tr><td>").Append(o["orderId"]).Append("</td><td>").Append(o["customer"])
                      .Append("</td><td>").Append(o["status"]).Append("</td><td>$").Append(o["total"])
                      .Append("</td><td>").Append(o["date"]).Append("</td></tr>");
                }
                OrderRows.Text = sb.ToString();
                metaLine.InnerText = "Orders loaded from App tier at " + ApiBaseUrl + "  |  Rows: " + rows.Count;
            }
            catch (Exception ex)
            {
                metaLine.InnerText = "Could not reach App tier: " + ex.Message;
                metaLine.Attributes["class"] = "error";
            }
        }
    </script>
</body>
</html>
'@
Set-Content -Path "$siteRoot\default.aspx" -Value $defaultAspx -Encoding UTF8

Import-Module WebAdministration
if (-not (Get-Website -Name "ContosoRetail" -ErrorAction SilentlyContinue)) {
    New-Website -Name "ContosoRetail" -PhysicalPath $siteRoot -Port 80 -Force
} else {
    Set-ItemProperty "IIS:\Sites\ContosoRetail" -Name physicalPath -Value $siteRoot
}
Remove-Website -Name "Default Web Site" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "HTTP 80" -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow -ErrorAction SilentlyContinue

Write-Output "============================================================"
Write-Output "ContosoRetail web front door deployed."
Write-Output "Browse to: http://<this-vm-private-ip>/  (via jumpbox or after migration)"
Write-Output "Calls App tier at: http://${AppServer}:${ApiPort}/"
Write-Output "============================================================"
