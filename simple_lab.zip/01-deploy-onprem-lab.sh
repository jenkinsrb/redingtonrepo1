#!/usr/bin/env bash
# ============================================================================
# Simulated On-Prem Environment on Azure -- 4-tier ContosoRetail app
# Purpose: Stand up a "corporate data center" (VNet + Web + App/API + DB +
#          File Server) that you will later migrate to (a) Azure via Azure
#          Migrate and (b) AWS via AWS Application Migration Service (MGN),
#          side by side. The multi-tier design gives dependency-analysis and
#          wave-planning demos something real to show.
#
# Prereqs: az CLI logged in (az login), Owner/Contributor on target subscription
# Files required in the same directory:
#   02-webapp-setup.ps1  03-database-setup.ps1  04-fileserver-setup.ps1  05-appapi-setup.ps1
# ============================================================================
set -euo pipefail

# ---- Variables (edit as needed) -------------------------------------------
LOCATION="eastus"
RG="rg-onprem-simulated"
VNET_NAME="vnet-corp-datacenter"
VNET_PREFIX="10.50.0.0/16"

SUBNET_WEB="snet-web";     SUBNET_WEB_PREFIX="10.50.1.0/24"
SUBNET_DB="snet-db";       SUBNET_DB_PREFIX="10.50.2.0/24"
SUBNET_MGMT="snet-mgmt";   SUBNET_MGMT_PREFIX="10.50.3.0/24"
SUBNET_SVC="snet-svc";     SUBNET_SVC_PREFIX="10.50.4.0/24"   # app tier + file server

ADMIN_USER="labadmin"
ADMIN_PASS="ChangeMe!$(openssl rand -hex 4)"
SVC_PASS="SvcAcct!$(openssl rand -hex 4)"     # shared account used for App<->FileServer SMB auth

VM_JUMP="onprem-jump01"
VM_WEB="onprem-web01"
VM_APP="onprem-app01"
VM_DB="onprem-db01"
VM_FS="onprem-fs01"

API_PORT=8081

echo "Generated admin password: $ADMIN_PASS   (save this now)"
echo "Generated svcapp password: $SVC_PASS     (save this now)"

# ---- Resource group + network ----------------------------------------------
az group create -n "$RG" -l "$LOCATION" -o table

az network vnet create -g "$RG" -n "$VNET_NAME" \
  --address-prefix "$VNET_PREFIX" \
  --subnet-name "$SUBNET_WEB" --subnet-prefix "$SUBNET_WEB_PREFIX" -o table

az network vnet subnet create -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_DB"   --address-prefix "$SUBNET_DB_PREFIX" -o table
az network vnet subnet create -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_MGMT" --address-prefix "$SUBNET_MGMT_PREFIX" -o table
az network vnet subnet create -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_SVC"  --address-prefix "$SUBNET_SVC_PREFIX" -o table

# ---- NSGs: mimic a segmented on-prem network -------------------------------
# Web tier: HTTP from Internet, RDP only from mgmt
az network nsg create -g "$RG" -n "nsg-web" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-web" -n Allow-HTTP-Inbound \
  --priority 100 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 80 443 --source-address-prefixes Internet -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-web" -n Allow-RDP-From-Mgmt \
  --priority 110 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 3389 --source-address-prefixes "$SUBNET_MGMT_PREFIX" -o none
az network vnet subnet update -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_WEB" --network-security-group "nsg-web" -o none

# App/File Server tier: API port + SMB only from web/svc subnets, RDP from mgmt
az network nsg create -g "$RG" -n "nsg-svc" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-svc" -n Allow-Api-From-Web \
  --priority 100 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges "$API_PORT" --source-address-prefixes "$SUBNET_WEB_PREFIX" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-svc" -n Allow-SMB-Intra-Svc \
  --priority 110 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 445 --source-address-prefixes "$SUBNET_SVC_PREFIX" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-svc" -n Allow-RDP-From-Mgmt \
  --priority 120 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 3389 --source-address-prefixes "$SUBNET_MGMT_PREFIX" -o none
az network vnet subnet update -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_SVC" --network-security-group "nsg-svc" -o none

# DB tier: SQL only from svc subnet (app tier), RDP from mgmt
az network nsg create -g "$RG" -n "nsg-db" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-db" -n Allow-SQL-From-Svc \
  --priority 100 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 1433 --source-address-prefixes "$SUBNET_SVC_PREFIX" -o none
az network nsg rule create -g "$RG" --nsg-name "nsg-db" -n Allow-RDP-From-Mgmt \
  --priority 110 --direction Inbound --access Allow --protocol Tcp \
  --destination-port-ranges 3389 --source-address-prefixes "$SUBNET_MGMT_PREFIX" -o none
az network vnet subnet update -g "$RG" --vnet-name "$VNET_NAME" -n "$SUBNET_DB" --network-security-group "nsg-db" -o none

# ---- Jumpbox (your only public entry point) --------------------------------
az vm create -g "$RG" -n "$VM_JUMP" \
  --image Win2022Datacenter --size Standard_B2s \
  --vnet-name "$VNET_NAME" --subnet "$SUBNET_MGMT" \
  --admin-username "$ADMIN_USER" --admin-password "$ADMIN_PASS" \
  --public-ip-sku Standard -o table

# ---- File server tier (no public IP) ---------------------------------------
az vm create -g "$RG" -n "$VM_FS" \
  --image Win2022Datacenter --size Standard_B2s \
  --vnet-name "$VNET_NAME" --subnet "$SUBNET_SVC" \
  --admin-username "$ADMIN_USER" --admin-password "$ADMIN_PASS" \
  --public-ip-address "" -o table

# ---- DB tier (SQL Server Developer edition image, no public IP) -----------
az vm create -g "$RG" -n "$VM_DB" \
  --image "MicrosoftSQLServer:sql2022-ws2022:sqldev:latest" \
  --size Standard_D2s_v5 \
  --vnet-name "$VNET_NAME" --subnet "$SUBNET_DB" \
  --admin-username "$ADMIN_USER" --admin-password "$ADMIN_PASS" \
  --public-ip-address "" -o table

# ---- App/API tier (no public IP) -------------------------------------------
az vm create -g "$RG" -n "$VM_APP" \
  --image Win2022Datacenter --size Standard_D2s_v5 \
  --vnet-name "$VNET_NAME" --subnet "$SUBNET_SVC" \
  --admin-username "$ADMIN_USER" --admin-password "$ADMIN_PASS" \
  --public-ip-address "" -o table

# ---- Web front-door tier (no public IP -- reached only via jumpbox/LB) ----
az vm create -g "$RG" -n "$VM_WEB" \
  --image Win2022Datacenter --size Standard_D2s_v5 \
  --vnet-name "$VNET_NAME" --subnet "$SUBNET_WEB" \
  --admin-username "$ADMIN_USER" --admin-password "$ADMIN_PASS" \
  --public-ip-address "" -o table

# ============================================================================
# Application configuration -- order matters: FS -> DB -> App -> Web
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

FS_PRIVATE_IP=$(az vm list-ip-addresses -g "$RG" -n "$VM_FS"  --query "[0].virtualMachine.network.privateIpAddresses[0]" -o tsv)
DB_PRIVATE_IP=$(az vm list-ip-addresses -g "$RG" -n "$VM_DB"  --query "[0].virtualMachine.network.privateIpAddresses[0]" -o tsv)
APP_PRIVATE_IP=$(az vm list-ip-addresses -g "$RG" -n "$VM_APP" --query "[0].virtualMachine.network.privateIpAddresses[0]" -o tsv)
WEB_PRIVATE_IP=$(az vm list-ip-addresses -g "$RG" -n "$VM_WEB" --query "[0].virtualMachine.network.privateIpAddresses[0]" -o tsv)

echo "Configuring file server tier ($VM_FS)..."
az vm run-command invoke -g "$RG" -n "$VM_FS" \
  --command-id RunPowerShellScript \
  --scripts @"$SCRIPT_DIR/04-fileserver-setup.ps1" \
  --parameters "SvcPassword=$SVC_PASS" \
  --query "value[0].message" -o tsv

echo "Configuring database tier ($VM_DB)..."
DB_OUTPUT=$(az vm run-command invoke -g "$RG" -n "$VM_DB" \
  --command-id RunPowerShellScript \
  --scripts @"$SCRIPT_DIR/03-database-setup.ps1" \
  --query "value[0].message" -o tsv)
echo "$DB_OUTPUT"
APP_DB_PASSWORD=$(echo "$DB_OUTPUT" | grep -oP "App SQL password:\s*\K\S+" || true)

if [ -z "$APP_DB_PASSWORD" ]; then
  echo "WARNING: could not auto-parse the DB app password. Configure the app tier manually."
else
  echo "Configuring app/API tier ($VM_APP)..."
  az vm run-command invoke -g "$RG" -n "$VM_APP" \
    --command-id RunPowerShellScript \
    --scripts @"$SCRIPT_DIR/05-appapi-setup.ps1" \
    --parameters "DbServer=$DB_PRIVATE_IP" "DbPassword=$APP_DB_PASSWORD" \
                 "FileServer=$FS_PRIVATE_IP" "SvcPassword=$SVC_PASS" "ApiPort=$API_PORT" \
    --query "value[0].message" -o tsv

  echo "Configuring web front-door tier ($VM_WEB)..."
  az vm run-command invoke -g "$RG" -n "$VM_WEB" \
    --command-id RunPowerShellScript \
    --scripts @"$SCRIPT_DIR/02-webapp-setup.ps1" \
    --parameters "AppServer=$APP_PRIVATE_IP" "ApiPort=$API_PORT" \
    --query "value[0].message" -o tsv
fi

echo "============================================================"
echo "Done. Resource group: $RG"
echo "Jumpbox public IP:"
az vm show -d -g "$RG" -n "$VM_JUMP" --query publicIps -o tsv
echo ""
echo "Tier private IPs:"
echo "  Web  ($VM_WEB): $WEB_PRIVATE_IP"
echo "  App  ($VM_APP): $APP_PRIVATE_IP  (API on port $API_PORT)"
echo "  DB   ($VM_DB):  $DB_PRIVATE_IP"
echo "  FS   ($VM_FS):  $FS_PRIVATE_IP  (share \\\\$FS_PRIVATE_IP\\Invoices)"
echo ""
echo "From the jumpbox, browse to http://$WEB_PRIVATE_IP/ to see the"
echo "ContosoRetail dashboard (Products / Place Order / Recent Orders),"
echo "which calls the App tier, which calls the DB and syncs invoices to"
echo "the File Server every 2 minutes via a scheduled task."
echo "============================================================"
