# ============================================================================
# 04-fileserver-setup.ps1
# Run on: onprem-fs01
# Purpose: Stand up an SMB file share ("Invoices") that the app tier syncs
#          generated invoice files to. Adds a genuine cross-VM dependency
#          (SMB/445) to the app for dependency-mapping demos.
#
# Usage: .\04-fileserver-setup.ps1 -SvcPassword "Pick-A-Password1!"
# ============================================================================
param(
    [Parameter(Mandatory = $true)][string]$SvcPassword,
    [string]$SvcUser = "svcapp"
)

$shareRoot = "C:\ContosoShare"
$invoicesPath = "$shareRoot\Invoices"
New-Item -ItemType Directory -Path $invoicesPath -Force | Out-Null

# --- Dedicated local service account used by the app tier's sync job --------
$secPass = ConvertTo-SecureString $SvcPassword -AsPlainText -Force
if (-not (Get-LocalUser -Name $SvcUser -ErrorAction SilentlyContinue)) {
    New-LocalUser -Name $SvcUser -Password $secPass -PasswordNeverExpires -AccountNeverExpires -Description "ContosoRetail app-tier file sync account"
} else {
    Set-LocalUser -Name $SvcUser -Password $secPass
}

# --- NTFS + share permissions scoped to that account only -------------------
icacls $invoicesPath /grant "${SvcUser}:(OI)(CI)M" | Out-Null

if (-not (Get-SmbShare -Name "Invoices" -ErrorAction SilentlyContinue)) {
    New-SmbShare -Name "Invoices" -Path $invoicesPath -FullAccess $SvcUser | Out-Null
} else {
    Grant-SmbShareAccess -Name "Invoices" -AccountName $SvcUser -AccessRight Full -Force | Out-Null
}

# --- Sample seed invoices so the share isn't empty on first demo run --------
1..3 | ForEach-Object {
    $content = "ContosoRetail Invoice Sample #$_`nGenerated: $(Get-Date)`nStatus: Seed data (pre-migration)`n"
    Set-Content -Path "$invoicesPath\INV-SEED-$_.txt" -Value $content
}

# --- Open the firewall for SMB (File and Printer Sharing) -------------------
Get-NetFirewallRule -DisplayGroup "File and Printer Sharing" | Enable-NetFirewallRule

Write-Output "============================================================"
Write-Output "File share ready: \\$($env:COMPUTERNAME)\Invoices  (local path $invoicesPath)"
Write-Output "Service account: $SvcUser"
Write-Output "Give this same username/password to 05-appapi-setup.ps1 as -SvcUser/-SvcPassword"
Write-Output "so the app tier's scheduled sync job can authenticate over SMB."
Write-Output "============================================================"
