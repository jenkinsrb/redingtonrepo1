# ============================================================================
# 05-appapi-setup.ps1
# Run on: onprem-app01
# Purpose: Middle tier. Hosts JSON API endpoints (products, orders) backed
#          by SQL Server, and a scheduled background job that pushes
#          generated invoice files to the file server over SMB.
#
# Usage:
#   .\05-appapi-setup.ps1 -DbServer "10.50.2.4" -DbPassword "<from 03>" `
#       -FileServer "10.50.4.5" -SvcUser "svcapp" -SvcPassword "<from 04>"
# ============================================================================
param(
    [Parameter(Mandatory = $true)][string]$DbServer,
    [Parameter(Mandatory = $true)][string]$DbPassword,
    [Parameter(Mandatory = $true)][string]$FileServer,
    [Parameter(Mandatory = $true)][string]$SvcPassword,
    [string]$DbUser  = "contosoapp",
    [string]$DbName  = "ContosoRetail",
    [string]$SvcUser = "svcapp",
    [int]$ApiPort    = 8081
)

Install-WindowsFeature -Name Web-Server, Web-Asp-Net45, Web-Net-Ext45 -IncludeManagementTools

$siteRoot = "C:\inetpub\wwwroot\contosoapi"
$pendingPath = "C:\ContosoApp\PendingInvoices"
New-Item -ItemType Directory -Path $siteRoot -Force | Out-Null
New-Item -ItemType Directory -Path $pendingPath -Force | Out-Null

# --- web.config: connection string ------------------------------------------
$webConfig = @"
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <connectionStrings>
    <add name="ContosoDb"
         connectionString="Server=$DbServer;Database=$DbName;User Id=$DbUser;Password=$DbPassword;TrustServerCertificate=True;"
         providerName="System.Data.SqlClient" />
  </connectionStrings>
  <appSettings>
    <add key="PendingInvoicePath" value="$pendingPath" />
  </appSettings>
  <system.web>
    <compilation debug="false" targetFramework="4.8" />
    <httpRuntime targetFramework="4.8" />
  </system.web>
</configuration>
"@
Set-Content -Path "$siteRoot\web.config" -Value $webConfig -Encoding UTF8

# --- products.ashx: GET -> JSON array of products ----------------------------
$productsAshx = @'
<%@ WebHandler Language="C#" Class="ProductsHandler" %>
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Configuration;

public class ProductsHandler : IHttpHandler
{
    public void ProcessRequest(HttpContext ctx)
    {
        ctx.Response.ContentType = "application/json";
        string connStr = ConfigurationManager.ConnectionStrings["ContosoDb"].ConnectionString;
        var sb = new StringBuilder("[");
        try
        {
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT Sku, Name, Category, Price, StockQty, LastUpdated FROM Products ORDER BY ProductId", conn);
                using (var r = cmd.ExecuteReader())
                {
                    bool first = true;
                    while (r.Read())
                    {
                        if (!first) sb.Append(",");
                        first = false;
                        sb.Append("{")
                          .Append("\"sku\":\"").Append(r["Sku"]).Append("\",")
                          .Append("\"name\":\"").Append(r["Name"].ToString().Replace("\"","'")).Append("\",")
                          .Append("\"category\":\"").Append(r["Category"]).Append("\",")
                          .Append("\"price\":").Append(Convert.ToDecimal(r["Price"]).ToString(System.Globalization.CultureInfo.InvariantCulture)).Append(",")
                          .Append("\"stock\":").Append(r["StockQty"]).Append(",")
                          .Append("\"updated\":\"").Append(Convert.ToDateTime(r["LastUpdated"]).ToString("s")).Append("\"")
                          .Append("}");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ctx.Response.StatusCode = 500;
            sb.Clear();
            sb.Append("{\"error\":\"").Append(ex.Message.Replace("\"","'")).Append("\"}");
            ctx.Response.Write(sb.ToString());
            return;
        }
        sb.Append("]");
        ctx.Response.Write(sb.ToString());
    }
    public bool IsReusable { get { return true; } }
}
'@
Set-Content -Path "$siteRoot\products.ashx" -Value $productsAshx -Encoding UTF8

# --- orders.ashx: GET -> recent orders JSON, POST -> place a new order ------
$ordersAshx = @'
<%@ WebHandler Language="C#" Class="OrdersHandler" %>
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Configuration;
using System.IO;

public class OrdersHandler : IHttpHandler
{
    public void ProcessRequest(HttpContext ctx)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ContosoDb"].ConnectionString;
        if (ctx.Request.HttpMethod == "POST")
        {
            PlaceOrder(ctx, connStr);
            return;
        }
        ListOrders(ctx, connStr);
    }

    private void ListOrders(HttpContext ctx, string connStr)
    {
        ctx.Response.ContentType = "application/json";
        var sb = new StringBuilder("[");
        using (var conn = new SqlConnection(connStr))
        {
            conn.Open();
            var cmd = new SqlCommand(@"
                SELECT TOP 20 o.OrderId, c.FullName, o.Status, o.TotalAmount, o.OrderDate
                FROM Orders o JOIN Customers c ON c.CustomerId = o.CustomerId
                ORDER BY o.OrderId DESC", conn);
            using (var r = cmd.ExecuteReader())
            {
                bool first = true;
                while (r.Read())
                {
                    if (!first) sb.Append(",");
                    first = false;
                    sb.Append("{")
                      .Append("\"orderId\":").Append(r["OrderId"]).Append(",")
                      .Append("\"customer\":\"").Append(r["FullName"].ToString().Replace("\"","'")).Append("\",")
                      .Append("\"status\":\"").Append(r["Status"]).Append("\",")
                      .Append("\"total\":").Append(Convert.ToDecimal(r["TotalAmount"]).ToString(System.Globalization.CultureInfo.InvariantCulture)).Append(",")
                      .Append("\"date\":\"").Append(Convert.ToDateTime(r["OrderDate"]).ToString("s")).Append("\"")
                      .Append("}");
                }
            }
        }
        sb.Append("]");
        ctx.Response.Write(sb.ToString());
    }

    private void PlaceOrder(HttpContext ctx, string connStr)
    {
        string customerName = ctx.Request.Form["customerName"];
        string sku = ctx.Request.Form["sku"];
        int qty;
        if (string.IsNullOrWhiteSpace(customerName) || string.IsNullOrWhiteSpace(sku) ||
            !int.TryParse(ctx.Request.Form["qty"], out qty) || qty < 1)
        {
            ctx.Response.StatusCode = 400;
            ctx.Response.ContentType = "text/plain";
            ctx.Response.Write("Missing or invalid fields: customerName, sku, qty");
            return;
        }

        int newOrderId = 0;
        try
        {
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                var cmd = new SqlCommand("usp_PlaceOrder", conn) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("@CustomerName", customerName);
                cmd.Parameters.AddWithValue("@Sku", sku);
                cmd.Parameters.AddWithValue("@Quantity", qty);
                var outParam = new SqlParameter("@NewOrderId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(outParam);
                cmd.ExecuteNonQuery();
                newOrderId = (int)outParam.Value;
            }

            // Drop an invoice file locally; the scheduled sync job pushes it to the file server.
            string pendingPath = ConfigurationManager.AppSettings["PendingInvoicePath"];
            Directory.CreateDirectory(pendingPath);
            string invoiceText = string.Format(
                "ContosoRetail Invoice\nOrderId: {0}\nCustomer: {1}\nSKU: {2}\nQty: {3}\nGenerated (app tier): {4}\n",
                newOrderId, customerName, sku, qty, DateTime.UtcNow.ToString("s"));
            File.WriteAllText(Path.Combine(pendingPath, "INV-" + newOrderId + ".txt"), invoiceText);

            ctx.Response.ContentType = "text/html";
            ctx.Response.Write("<html><body><p>Order #" + newOrderId + " placed for " +
                HttpUtility.HtmlEncode(customerName) + ".</p><p><a href=\"javascript:history.back()\">Back</a></p></body></html>");
        }
        catch (Exception ex)
        {
            ctx.Response.StatusCode = 500;
            ctx.Response.ContentType = "text/plain";
            ctx.Response.Write("Order failed: " + ex.Message);
        }
    }

    public bool IsReusable { get { return true; } }
}
'@
Set-Content -Path "$siteRoot\orders.ashx" -Value $ordersAshx -Encoding UTF8

# --- IIS site on a dedicated API port ----------------------------------------
Import-Module WebAdministration
if (-not (Get-Website -Name "ContosoApi" -ErrorAction SilentlyContinue)) {
    New-Website -Name "ContosoApi" -PhysicalPath $siteRoot -Port $ApiPort -Force
} else {
    Set-ItemProperty "IIS:\Sites\ContosoApi" -Name physicalPath -Value $siteRoot
}
Remove-Website -Name "Default Web Site" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "ContosoApi $ApiPort" -Direction Inbound -Protocol TCP -LocalPort $ApiPort -Action Allow -ErrorAction SilentlyContinue

# --- Background job: push pending invoices to the file server over SMB ------
$syncScriptPath = "C:\ContosoApp\InvoiceSync.ps1"
$syncScript = @"
`$ErrorActionPreference = 'SilentlyContinue'
`$pending = '$pendingPath'
`$target  = '\\\\$FileServer\Invoices'
`$secure  = ConvertTo-SecureString '$SvcPassword' -AsPlainText -Force
`$cred    = New-Object System.Management.Automation.PSCredential('$SvcUser', `$secure)

try {
    New-SmbMapping -RemotePath `$target -UserName '$SvcUser' -Password '$SvcPassword' -ErrorAction Stop | Out-Null
} catch {}

Get-ChildItem -Path `$pending -Filter *.txt -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        Copy-Item -Path `$_.FullName -Destination `$target -Force
        Remove-Item -Path `$_.FullName -Force
    } catch {
        Add-Content -Path 'C:\ContosoApp\sync-errors.log' -Value "`$(Get-Date) - failed to sync `$(`$_.Name): `$_"
    }
}
Remove-SmbMapping -RemotePath `$target -Force -ErrorAction SilentlyContinue
"@
Set-Content -Path $syncScriptPath -Value $syncScript -Encoding UTF8

$taskName = "ContosoInvoiceSync"
schtasks /Delete /TN $taskName /F 2>$null | Out-Null
schtasks /Create /TN $taskName /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$syncScriptPath`"" `
    /SC MINUTE /MO 2 /RU $SvcUser /RP $SvcPassword /RL LIMITED /F | Out-Null

Write-Output "============================================================"
Write-Output "ContosoApi deployed on port $ApiPort (products.ashx, orders.ashx)"
Write-Output "DB target: $DbServer / $DbName"
Write-Output "Scheduled task '$taskName' syncs $pendingPath -> \\$FileServer\Invoices every 2 min"
Write-Output "as user $SvcUser."
Write-Output "============================================================"
