$records = @(
    [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().AddHours(-1).ToString("o")
        EventType     = "FileAccess"
        UserName      = "rpatel"
        DeviceName    = "WKSTN-119"
        FileName      = "Customer_Master_List.xlsx"
        Action        = "Downloaded"
        DataVolumeMB  = 145
        Destination   = "USB-Drive"
    },
    [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().AddMinutes(-30).ToString("o")
        EventType     = "CloudUpload"
        UserName      = "rpatel"
        DeviceName    = "WKSTN-119"
        FileName      = "Customer_Master_List.xlsx"
        Action        = "UploadedToPersonalCloud"
        Destination   = "personal-dropbox.com"
        DataVolumeMB  = 145
    }
)
Send-SentinelLabLogs @Cfg -Records $records