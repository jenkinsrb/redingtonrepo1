$attackerIP = "203.0.113.45"
$records = @()
1..50 | ForEach-Object {
    $records += [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().AddSeconds(-($_ * 5)).ToString("o")
        EventType     = "FailedLogin"
        SourceIP      = $attackerIP
        UserName      = "jdoe@contoso.com"
        Application   = "O365"
        Result        = "Failure"
        Country       = "RU"
        Details       = "Invalid password attempt $_"
    }
}
# one successful login right after — classic brute-force-then-success pattern
$records += [PSCustomObject]@{
    TimeGenerated = (Get-Date).ToUniversalTime().ToString("o")
    EventType     = "FailedLogin"
    SourceIP      = $attackerIP
    UserName      = "jdoe@contoso.com"
    Application   = "O365"
    Result        = "Success"
    Country       = "RU"
    Details       = "Login succeeded after repeated failures"
}

Send-SentinelLabLogs @Cfg -Records $records