# Send-SentinelLabLogs.ps1
# Reusable function to push JSON log records into the SentinelLab_CL custom table
# via the Azure Monitor Logs Ingestion API.

function Get-IngestAccessToken {
    param(
        [string]$TenantId,
        [string]$ClientId,
        [string]$ClientSecret
    )
    $body = @{
        client_id     = $ClientId
        scope         = "https://monitor.azure.com/.default"
        client_secret = $ClientSecret
        grant_type    = "client_credentials"
    }
    $tokenUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $resp = Invoke-RestMethod -Uri $tokenUri -Method Post -Body $body -ContentType "application/x-www-form-urlencoded"
    return $resp.access_token
}

function Send-SentinelLabLogs {
    param(
        [Parameter(Mandatory)] [string]$TenantId,
        [Parameter(Mandatory)] [string]$ClientId,
        [Parameter(Mandatory)] [string]$ClientSecret,
        [Parameter(Mandatory)] [string]$DceUri,        
        [Parameter(Mandatory)] [string]$DcrImmutableId,# e.g. dcr-0123456789abcdef0123456789abcdef
        [Parameter(Mandatory)] [string]$StreamName,    # e.g. Custom-SentinelLab_CL
        [Parameter(Mandatory)] [Array]$Records         # array of hashtables/PSCustomObjects
    )

    $token = Get-IngestAccessToken -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret
    $uri = ($DceUri.Trim().TrimEnd('/')) + "/dataCollectionRules/" + ($DcrImmutableId.Trim()) + "/streams/" + ($StreamName.Trim()) + "?api-version=2023-01-01"
	Write-Host "DEBUG URI: [$uri]" -ForegroundColor Cyan
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type"  = "application/json"
    }

    $body = $Records | ConvertTo-Json -Depth 5
    # Single-object arrays need to stay arrays for the API
    if ($Records.Count -eq 1) { $body = "[$body]" }

    try {
    $result = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body -ErrorAction Stop
    Write-Host "Sent $($Records.Count) record(s) successfully." -ForegroundColor Green
}
catch {
    Write-Host "STATUS: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    if ($_.ErrorDetails.Message) {
        Write-Host "BODY: $($_.ErrorDetails.Message)" -ForegroundColor Yellow
    }
    else {
        $stream = $_.Exception.Response.GetResponseStream()
        $stream.Position = 0
        $reader = New-Object System.IO.StreamReader($stream)
        Write-Host "BODY: $($reader.ReadToEnd())" -ForegroundColor Yellow
    }
}
}