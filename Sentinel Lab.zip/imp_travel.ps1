$records = @(
    [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().AddMinutes(-10).ToString("o")
        EventType     = "SignIn"
        UserName      = "mgarcia@contoso.com"
        SourceIP      = "198.51.100.10"
        Country       = "IN"
        Application   = "O365"
        Result        = "Success"
    },
    [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString("o")
        EventType     = "SignIn"
        UserName      = "mgarcia@contoso.com"
        SourceIP      = "203.0.113.99"
        Country       = "BR"
        Application   = "O365"
        Result        = "Success"
    }
)
Send-SentinelLabLogs @Cfg -Records $records