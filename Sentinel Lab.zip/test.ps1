$token = Get-IngestAccessToken -TenantId $Cfg.TenantId -ClientId $Cfg.ClientId -ClientSecret $Cfg.ClientSecret

$uri = "$($Cfg.DceUri)/dataCollectionRules/$($Cfg.DcrImmutableId)/streams/$($Cfg.StreamName)?api-version=2023-01-01"

$testRecord = @(
    @{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString("o")
        EventType     = "FailedLogin"
        SourceIP      = "203.0.113.45"
        UserName      = "jdoe@contoso.com"
        Application   = "O365"
        Result        = "Failure"
        Country       = "RU"
        Details       = "test"
    }
)

$body = $testRecord | ConvertTo-Json -Depth 5
$body = "[" + $body.TrimStart('[').TrimEnd(']') + "]"   # ensure it's wrapped as an array
Write-Host "PAYLOAD:" -ForegroundColor Cyan
Write-Host $body

$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type"  = "application/json"
}

try {
    Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body -ErrorAction Stop
    Write-Host "SUCCESS" -ForegroundColor Green
}
catch {
    Write-Host "STATUS: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    if ($_.ErrorDetails.Message) {
        Write-Host "BODY: $($_.ErrorDetails.Message)" -ForegroundColor Yellow
    }
    else {
        $stream = $_.Exception.Response.GetResponseStream()
        $stream.Position = 0
        $reader = New-Object System.IO.StreamReader($stream)
        Write-Host "BODY: $($reader.ReadToEnd())" -ForegroundColor Yellow
    }
}