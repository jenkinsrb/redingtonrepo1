. .\Send-SentinelLabLogs.ps1
$Cfg = @{
    TenantId       = "98679796-37ce-40d9-80aa-e1387a0b4181"
    ClientId       = "d07eadb7-29ed-4c26-a004-320ef91a20e8"
    ClientSecret   = "shN8Q~1RKNyyNcRN5nkSIvBQypMxOii85vV6Bc2u"
    DceUri         = "https://dce-sentinel-lab-y8c5.japanwest-1.ingest.monitor.azure.com"
    DcrImmutableId = "dcr-c61080004d89421ab0c15da5f3594c13"
    StreamName     = "Custom-SentinelLab_CL_CL"
}