$records = @()
$internalHost = "10.0.5.22"
$targetPorts  = 1..25 | Get-Random -Count 20
foreach ($port in $targetPorts) {
    $records += [PSCustomObject]@{
        TimeGenerated  = (Get-Date).ToUniversalTime().AddSeconds(-(Get-Random -Minimum 1 -Maximum 120)).ToString("o")
        EventType      = "NetworkConnection"
        SourceIP       = $internalHost
        DestinationIP  = "10.0.5.$(Get-Random -Minimum 1 -Maximum 254)"
        DestinationPort= $port
        Protocol       = "TCP"
        Action         = "Allowed"
        BytesSent      = Get-Random -Minimum 40 -Maximum 200
    }
}
Send-SentinelLabLogs @Cfg -Records $records