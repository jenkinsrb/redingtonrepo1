$records = @(
    [PSCustomObject]@{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString("o")
        EventType     = "EmailReceived"
        Recipient     = "finance-team@contoso.com"
        Sender        = "ceo-urgent@contoso-secure.co"
        Subject       = "URGENT: Wire transfer approval needed today"
        AttachmentName= "Invoice_2026.pdf.exe"
        SpamScore     = 8.7
        Verdict       = "Phish"
        LinkDomain    = "contoso-login-verify.com"
    }
)
Send-SentinelLabLogs @Cfg -Records $records